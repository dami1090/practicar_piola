int parserEmployee(char* path , ArrayList* pArrayListEmployee);
