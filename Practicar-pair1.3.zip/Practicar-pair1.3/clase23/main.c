#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "clase23.h"

int main()
{
    int size;
    int index;
    int edadAux;
    char nombreAux[20];
    char preguntarSalir='n';
    Persona** lista;
    persona_initLista(lista,&size,&index);
    do
    {
        Persona* persona = persona_newPersona();
        preguntarNombre(nombreAux);
        if(persona_setName(persona,nombreAux))
            printf("El nombre no es valido\n");
        edadAux = preguntarEdad();
        if(persona_setEdad(persona,edadAux))
            printf("La edad no es v�lida\n");
        persona_addPersona(persona,lista,&index,&size);
        printf("desea salir?[s|n]\n");
        scanf("%c",&preguntarSalir);
        preguntarSalir=tolower(preguntarSalir);
    }
    while(preguntarSalir!='s');
    return 0;
}
