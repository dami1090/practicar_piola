#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Employee.h"


int parserEmployee(FILE* archiEmpleados, ArrayList* pArrayListEmployee)
{

    Employee* empleado;
    int retorno;
    char id[15],name[50],lastName[50],isEmpty[15];

    archiEmpleados = fopen ("data.csv", "r");
    if(archiEmpleados==NULL)
    {
        retorno=0;
    }
    else
    {
      fscanf(archiEmpleados, "%[^,],%[^,],%[^,],%[^\n]\n", id, name, lastName,isEmpty);
    while(!feof(archiEmpleados))
    {

        fscanf(archiEmpleados, "%[^,],%[^,],%[^,],%[^\n]\n", id, name, lastName,isEmpty);

        empleado=employee_new();

        employee_setId(empleado, atoi(id));
        employee_setName(empleado,name);
        employee_setLastName(empleado,lastName);
        if(stricmp(isEmpty,"true")==0)
        {
            employee_setIsEmpty(empleado,1);
        }
        else
        {
            employee_setIsEmpty(empleado,0);
        }

       // printf("%s - %s - %s - %s\n", id, name, lastName,isEmpty);
        //printf("%d - %s - %s - %s\n", empleado.id, empleado.name,empleado.lastName, empleado.isEmpty);
        pArrayListEmployee->add(pArrayListEmployee,empleado);
    }
    retorno=1;
    }
    fclose(archiEmpleados);

    return retorno;
}


