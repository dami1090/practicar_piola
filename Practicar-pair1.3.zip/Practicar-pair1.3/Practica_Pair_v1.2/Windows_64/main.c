#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Employee.h"

/****************************************************
    Menu:
        1. Parse del archivo data.csv
        2. Listar Empleados
        3. Ordenar por nombre
        4. Agregar un elemento
        5. Elimina un elemento
        6. Listar Empleados (Desde/Hasta)
*****************************************************/


int main()
{

    FILE *archiEmpleados;
    ArrayList* listaEmpleados;
    Employee* empleado;
    int aux,i;
    char name[50],lastName[50],isEmpty[50],id[15];
    int cont=1;
    char seguir='s';
    int opcion=0;

    listaEmpleados= al_newArrayList();
    while(seguir=='s')
    {


        printf("1- Parse del archivo data.cvs\n");
        printf("2- Listar Empleados\n");
        printf("3- Ordenar por nombre\n");
        printf("4- Agregar un elemento\n");
        printf("5- Elimina un elemento\n");
        printf("6- Listar Empleados (Desde/Hasta)\n");
        printf("7- Salir\n");

        setbuf(stdin,NULL);
        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            aux=parserEmployee(archiEmpleados,listaEmpleados);
            if(aux!=1)
            {
                printf("no se pudo cargar el archivo\n");
            }
            else
            {
                printf("se cargo con exito el archivo\n");
            }

            break;
        case 2:
            mostrarTodo(listaEmpleados);

            break;
        case 3:
            break;
        case 4:
            empleado=employee_new();

            listaEmpleados->add(listaEmpleados,empleado);
            break;
        case 5:
            break;
        case 6:
            break;
        case 7:
            seguir='n';
            break;
        default:
            system("cls");
            printf("\n\tOpcion invalida\n\n");
            break;
        }
        system("pause");
        system("cls");
    }

    return 0;
}
