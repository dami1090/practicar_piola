#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Employee.h"


int employee_compare(void* pEmployeeA,void* pEmployeeB)
{
    return 0;
}

void mostrarTodo(ArrayList* listaEmpleados)
{
    int i,cont=1;
    Employee* empleado;
    for(i=0; i<listaEmpleados->len(listaEmpleados); i++)
    {
        if(cont %250 == 0)
       {
           system("pause");
       }
       cont++;
        empleado=(Employee*)listaEmpleados->get(listaEmpleados,i);
        employee_print(empleado);
    }

}

void employee_print(Employee* this)
{
    printf("%d\t%-15s\t%-15s\t%-20d\n",this->id,this->name,this->lastName,this->isEmpty);
}


Employee* employee_new(void)
{

    Employee* returnAux = NULL;
    Employee* auxMemo;
    auxMemo=(Employee*)malloc(sizeof(Employee));
    if(auxMemo!=NULL)
    {
        returnAux=auxMemo;
    }
    else
    {
        printf("No hay memoria disponible\n");
    }

    return returnAux;

}

void employee_delete(Employee* this)
{


}

int employee_setId(Employee* this, int id)
{

    this->id = id;

    return 0;

}

int employee_setName(Employee* this,char* str)
{
    strcpy(this->name,str);
    return 0;
}

int employee_setLastName(Employee* this,char* str)
{
    strcpy(this->lastName,str);
    return 0;
}

int employee_setIsEmpty(Employee* this,int num)
{
    this->isEmpty=num;
    return 0;
}

int employee_getId(Employee* this)
{

    return 0;

}


